export type ServiceStatus = 'healthy' | 'degraded' | 'down' | 'starting';

export interface Microservice {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  version: string;
  cpu: number;
  memory: number;
  uptime: string;
  lastDeployment: string;
}

export interface DomainStats {
  domain: string;
  count: number;
  healthy: number;
}

export interface LanguageStats {
  language: string;
  count: number;
  color: string;
}
