import React, { useState, useMemo, ReactNode } from 'react';
import { 
  LayoutDashboard, 
  Layers, 
  Activity, 
  Settings, 
  Search, 
  Filter, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Cpu, 
  Database,
  ChevronRight,
  Menu,
  X,
  Zap,
  Box,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateMockServices, DOMAINS, LANGUAGES } from './constants';
import { Microservice, ServiceStatus } from './types';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid 
} from 'recharts';

const INITIAL_SERVICES = generateMockServices(1000);

export default function App() {
  const [services, setServices] = useState<Microservice[]>(INITIAL_SERVICES);
  const [selectedDomain, setSelectedDomain] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [view, setView] = useState<'grid' | 'list' | 'analytics'>('grid');
  const [selectedService, setSelectedService] = useState<Microservice | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<ServiceStatus | null>(null);
  const [wsStatus, setWsStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('connecting');
  const [wsError, setWsError] = useState<string | null>(null);
  const [reconnectTrigger, setReconnectTrigger] = useState(0);

  // WebSocket Connection
  React.useEffect(() => {
    let socket: WebSocket | null = null;
    let reconnectTimeout: NodeJS.Timeout;

    const connect = () => {
      setWsStatus('connecting');
      setWsError(null);

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;
      
      try {
        socket = new WebSocket(wsUrl);

        socket.onopen = () => {
          console.log('WebSocket Connected');
          setWsStatus('connected');
          setWsError(null);
        };

        socket.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data);
            if (message.type === 'SERVICE_UPDATES') {
              const updates = message.data;
              setServices(prev => {
                const next = [...prev];
                updates.forEach((update: any) => {
                  const index = next.findIndex(s => s.id === update.id);
                  if (index !== -1) {
                    next[index] = { ...next[index], ...update };
                  }
                });
                return next;
              });

              // Update selected service if it was updated
              if (selectedService) {
                const update = updates.find((u: any) => u.id === selectedService.id);
                if (update) {
                  setSelectedService(prev => prev ? { ...prev, ...update } : null);
                }
              }
            }
          } catch (err) {
            console.error('Failed to parse WS message', err);
            // Don't disconnect on parse error, just log it
          }
        };

        socket.onerror = (event) => {
          console.error('WebSocket Error:', event);
          setWsStatus('error');
          setWsError('A network error occurred while connecting to the live stream.');
        };

        socket.onclose = (event) => {
          console.log('WebSocket Disconnected', event.code, event.reason);
          setWsStatus('disconnected');
          
          // Auto-reconnect after 5 seconds if not closed cleanly
          if (event.code !== 1000) {
            reconnectTimeout = setTimeout(() => {
              setReconnectTrigger(prev => prev + 1);
            }, 5000);
          }
        };
      } catch (err) {
        console.error('Failed to create WebSocket', err);
        setWsStatus('error');
        setWsError('Failed to initialize live stream connection.');
      }
    };

    connect();

    return () => {
      if (socket) socket.close(1000);
      clearTimeout(reconnectTimeout);
    };
  }, [reconnectTrigger, selectedService?.id]);

  const filteredServices = useMemo(() => {
    return services.filter(svc => {
      const matchesDomain = !selectedDomain || svc.domain === selectedDomain;
      const matchesStatus = !selectedStatus || svc.status === selectedStatus;
      const matchesSearch = svc.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           svc.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesDomain && matchesStatus && matchesSearch;
    });
  }, [selectedDomain, selectedStatus, searchQuery, services]);

  const stats = useMemo(() => {
    const total = filteredServices.length;
    const healthy = filteredServices.filter(s => s.status === 'healthy').length;
    const degraded = filteredServices.filter(s => s.status === 'degraded').length;
    const down = filteredServices.filter(s => s.status === 'down').length;
    
    const langCounts = LANGUAGES.map(lang => ({
      name: lang.name,
      value: filteredServices.filter(s => s.language === lang.name).length,
      color: lang.color
    })).filter(l => l.value > 0);

    return { total, healthy, degraded, down, langCounts };
  }, [filteredServices]);

  return (
    <div className="flex h-screen bg-[#0A0A0B] text-[#E4E3E0] font-mono overflow-hidden">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 0, opacity: isSidebarOpen ? 1 : 0 }}
        className="border-r border-[#1F1F22] bg-[#0F0F11] flex-shrink-0 overflow-hidden relative"
      >
        <div className="p-6 border-b border-[#1F1F22] flex items-center gap-3">
          <div className="w-8 h-8 bg-[#F27D26] rounded flex items-center justify-center text-black font-bold shadow-[0_0_15px_rgba(242,125,38,0.3)]">T</div>
          <h1 className="text-lg font-bold tracking-tighter uppercase italic">TimberFlow</h1>
        </div>
        
        <nav className="p-4 space-y-1 h-[calc(100vh-160px)] overflow-y-auto custom-scrollbar">
          <div className="text-[10px] uppercase tracking-widest text-[#52525B] mb-4 px-2">Domains</div>
          <button 
            onClick={() => setSelectedDomain(null)}
            className={`w-full text-left px-3 py-2 rounded text-sm transition-colors flex items-center gap-3 ${!selectedDomain ? 'bg-[#1F1F22] text-[#F27D26]' : 'hover:bg-[#1F1F22]/50 text-[#A1A1AA]'}`}
          >
            <Globe size={16} />
            Global Overview
          </button>
          {DOMAINS.map(domain => (
            <button 
              key={domain}
              onClick={() => setSelectedDomain(domain)}
              className={`w-full text-left px-3 py-2 rounded text-sm transition-colors flex items-center gap-3 ${selectedDomain === domain ? 'bg-[#1F1F22] text-[#F27D26]' : 'hover:bg-[#1F1F22]/50 text-[#A1A1AA]'}`}
            >
              <Box size={16} />
              <span className="truncate">{domain}</span>
            </button>
          ))}

          <div className="h-4" />
          <div className="text-[10px] uppercase tracking-widest text-[#52525B] mb-4 px-2">Status</div>
          <button 
            onClick={() => setSelectedStatus(null)}
            className={`w-full text-left px-3 py-2 rounded text-sm transition-colors flex items-center gap-3 ${!selectedStatus ? 'bg-[#1F1F22] text-[#F27D26]' : 'hover:bg-[#1F1F22]/50 text-[#A1A1AA]'}`}
          >
            <Filter size={16} />
            All Statuses
          </button>
          <StatusFilterButton 
            status="healthy" 
            active={selectedStatus === 'healthy'} 
            onClick={() => setSelectedStatus('healthy')} 
            icon={<CheckCircle2 size={16} className="text-emerald-500" />} 
          />
          <StatusFilterButton 
            status="degraded" 
            active={selectedStatus === 'degraded'} 
            onClick={() => setSelectedStatus('degraded')} 
            icon={<Zap size={16} className="text-amber-500" />} 
          />
          <StatusFilterButton 
            status="down" 
            active={selectedStatus === 'down'} 
            onClick={() => setSelectedStatus('down')} 
            icon={<AlertCircle size={16} className="text-rose-500" />} 
          />
          <StatusFilterButton 
            status="starting" 
            active={selectedStatus === 'starting'} 
            onClick={() => setSelectedStatus('starting')} 
            icon={<Clock size={16} className="text-blue-500" />} 
          />
        </nav>

        <div className="absolute bottom-0 w-[280px] p-4 border-t border-[#1F1F22] bg-[#0F0F11]">
          <div className="flex items-center gap-3 p-2 rounded hover:bg-[#1F1F22] cursor-pointer transition-colors">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-red-600 border border-white/10" />
            <div>
              <div className="text-xs font-bold">Admin Node</div>
              <div className="text-[10px] text-[#52525B]">SRE-01-CLUSTER</div>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#0A0A0B]">
        {/* Header */}
        <header className="h-16 border-b border-[#1F1F22] flex items-center justify-between px-6 bg-[#0F0F11]/50 backdrop-blur-md z-10">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-[#1F1F22] rounded transition-colors"
            >
              <Menu size={20} />
            </button>
            <div className="h-4 w-px bg-[#1F1F22]" />
            <div className="flex items-center gap-2 text-sm text-[#A1A1AA]">
              <span className="text-[#52525B]">SYSTEM</span>
              <ChevronRight size={14} />
              <span>{selectedDomain || 'GLOBAL'}</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#52525B]" size={16} />
              <input 
                type="text" 
                placeholder="Search services..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#1F1F22] border-none rounded px-10 py-1.5 text-sm w-64 focus:ring-1 focus:ring-[#F27D26] outline-none transition-all"
              />
            </div>
            <div className="flex bg-[#1F1F22] p-1 rounded">
              <button 
                onClick={() => setView('grid')}
                className={`p-1.5 rounded transition-colors ${view === 'grid' ? 'bg-[#0A0A0B] text-[#F27D26]' : 'text-[#52525B] hover:text-[#A1A1AA]'}`}
              >
                <LayoutDashboard size={18} />
              </button>
              <button 
                onClick={() => setView('list')}
                className={`p-1.5 rounded transition-colors ${view === 'list' ? 'bg-[#0A0A0B] text-[#F27D26]' : 'text-[#52525B] hover:text-[#A1A1AA]'}`}
              >
                <Layers size={18} />
              </button>
              <button 
                onClick={() => setView('analytics')}
                className={`p-1.5 rounded transition-colors ${view === 'analytics' ? 'bg-[#0A0A0B] text-[#F27D26]' : 'text-[#52525B] hover:text-[#A1A1AA]'}`}
              >
                <Activity size={18} />
              </button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar relative">
          {/* Connection Error Banner */}
          <AnimatePresence>
            {(wsStatus === 'disconnected' || wsStatus === 'error') && (
              <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-rose-500/10 border border-rose-500/20 rounded-lg p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <AlertCircle className="text-rose-500" size={20} />
                  <div>
                    <p className="text-sm font-bold text-rose-500">Live Stream Disconnected</p>
                    <p className="text-[10px] text-rose-500/70 uppercase tracking-widest">
                      {wsError || 'The connection to the real-time update server was lost. Metrics are currently static.'}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setReconnectTrigger(prev => prev + 1)}
                  className="px-4 py-1.5 bg-rose-500 text-white text-[10px] font-bold uppercase tracking-widest rounded hover:bg-rose-600 transition-colors"
                >
                  Reconnect Now
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Stats Bar */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <StatCard label="Total Services" value={stats.total} icon={<Box size={20} />} color="text-white" />
            <StatCard label="Healthy Nodes" value={stats.healthy} icon={<CheckCircle2 size={20} />} color="text-emerald-500" />
            <StatCard label="Degraded" value={stats.degraded} icon={<Zap size={20} />} color="text-amber-500" />
            <StatCard label="Critical Down" value={stats.down} icon={<AlertCircle size={20} />} color="text-rose-500" />
          </div>

          <AnimatePresence mode="wait">
            {view === 'grid' && (
              <motion.div 
                key="grid"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="bg-[#0F0F11] border border-[#1F1F22] rounded-lg p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-lg font-bold tracking-tight">Service Health Grid</h2>
                      <p className="text-xs text-[#52525B]">Real-time visualization of 1,000 polyglot microservices</p>
                    </div>
                    <div className="flex items-center gap-4 text-[10px] uppercase tracking-widest text-[#52525B]">
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-emerald-500" /> Healthy</div>
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-amber-500" /> Degraded</div>
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-rose-500" /> Down</div>
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-blue-500" /> Starting</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-[repeat(auto-fill,minmax(12px,1fr))] gap-1.5">
                    {filteredServices.map((svc) => (
                      <motion.div 
                        key={svc.id}
                        whileHover={{ scale: 1.5, zIndex: 10 }}
                        onClick={() => setSelectedService(svc)}
                        className={`aspect-square rounded-[1px] transition-all cursor-pointer ${
                          svc.status === 'healthy' ? 'bg-emerald-500/40 hover:bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.2)]' :
                          svc.status === 'degraded' ? 'bg-amber-500/40 hover:bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.2)]' :
                          svc.status === 'down' ? 'bg-rose-500/40 hover:bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.2)]' :
                          'bg-blue-500/40 hover:bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.2)]'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-[#0F0F11] border border-[#1F1F22] rounded-lg p-6">
                    <h3 className="text-sm font-bold mb-6 uppercase tracking-widest text-[#52525B]">Language Distribution</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={stats.langCounts}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {stats.langCounts.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0F0F11', border: '1px solid #1F1F22', borderRadius: '4px' }}
                            itemStyle={{ color: '#E4E3E0', fontSize: '12px' }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      {stats.langCounts.slice(0, 9).map(lang => (
                        <div key={lang.name} className="flex items-center gap-2 text-[10px]">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: lang.color }} />
                          <span className="text-[#A1A1AA]">{lang.name}</span>
                          <span className="ml-auto font-bold">{lang.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#0F0F11] border border-[#1F1F22] rounded-lg p-6">
                    <h3 className="text-sm font-bold mb-6 uppercase tracking-widest text-[#52525B]">Resource Utilization</h3>
                    <div className="space-y-6">
                      <ResourceMetric label="Global CPU Load" value={42} color="bg-[#F27D26]" />
                      <ResourceMetric label="Memory Allocation" value={68} color="bg-emerald-500" />
                      <ResourceMetric label="Network Throughput" value={24} color="bg-blue-500" />
                      <ResourceMetric label="Disk I/O (Sawmill Cluster)" value={89} color="bg-rose-500" />
                    </div>
                    <div className="mt-12 p-4 border border-dashed border-[#1F1F22] rounded bg-[#1F1F22]/20">
                      <div className="flex items-center gap-3 text-xs text-amber-500 mb-2">
                        <AlertCircle size={14} />
                        <span className="font-bold">System Alert</span>
                      </div>
                      <p className="text-[10px] text-[#A1A1AA] leading-relaxed">
                        Sawmill IoT sensors (Rust) in the Manufacturing domain are reporting high latency. 
                        Scaling replica sets in the EU-WEST-1 region.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {view === 'list' && (
              <motion.div 
                key="list"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-[#0F0F11] border border-[#1F1F22] rounded-lg overflow-hidden"
              >
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#1F1F22] bg-[#1F1F22]/30">
                      <th className="p-4 text-[10px] uppercase tracking-widest text-[#52525B] font-bold">Service ID</th>
                      <th className="p-4 text-[10px] uppercase tracking-widest text-[#52525B] font-bold">Name</th>
                      <th className="p-4 text-[10px] uppercase tracking-widest text-[#52525B] font-bold">Language</th>
                      <th className="p-4 text-[10px] uppercase tracking-widest text-[#52525B] font-bold">Domain</th>
                      <th className="p-4 text-[10px] uppercase tracking-widest text-[#52525B] font-bold">Status</th>
                      <th className="p-4 text-[10px] uppercase tracking-widest text-[#52525B] font-bold text-right">CPU</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredServices.slice(0, 50).map(svc => (
                      <tr 
                        key={svc.id} 
                        onClick={() => setSelectedService(svc)}
                        className="border-b border-[#1F1F22] hover:bg-[#1F1F22]/50 transition-colors group cursor-pointer"
                      >
                        <td className="p-4 text-xs font-bold text-[#F27D26]">{svc.id}</td>
                        <td className="p-4 text-xs">{svc.name}</td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 rounded bg-[#1F1F22] text-[10px] font-bold border border-[#3F3F46]">
                            {svc.language}
                          </span>
                        </td>
                        <td className="p-4 text-[10px] text-[#A1A1AA]">{svc.domain}</td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <div className={`w-1.5 h-1.5 rounded-full ${
                              svc.status === 'healthy' ? 'bg-emerald-500' :
                              svc.status === 'degraded' ? 'bg-amber-500' :
                              svc.status === 'down' ? 'bg-rose-500' : 'bg-blue-500'
                            }`} />
                            <span className="text-[10px] uppercase font-bold">{svc.status}</span>
                          </div>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <div className="w-16 h-1 bg-[#1F1F22] rounded-full overflow-hidden">
                              <div className="h-full bg-[#F27D26]" style={{ width: `${svc.cpu}%` }} />
                            </div>
                            <span className="text-[10px] font-bold w-8">{svc.cpu}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredServices.length > 50 && (
                  <div className="p-4 text-center text-[10px] text-[#52525B] uppercase tracking-widest">
                    Showing 50 of {filteredServices.length} services. Use search to find specific nodes.
                  </div>
                )}
              </motion.div>
            )}

            {view === 'analytics' && (
              <motion.div 
                key="analytics"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-6"
              >
                <div className="bg-[#0F0F11] border border-[#1F1F22] rounded-lg p-6">
                  <h3 className="text-sm font-bold mb-6 uppercase tracking-widest text-[#52525B]">Deployment Frequency (Last 24h)</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stats.langCounts}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1F1F22" vertical={false} />
                        <XAxis 
                          dataKey="name" 
                          stroke="#52525B" 
                          fontSize={10} 
                          tickLine={false} 
                          axisLine={false}
                        />
                        <YAxis 
                          stroke="#52525B" 
                          fontSize={10} 
                          tickLine={false} 
                          axisLine={false}
                        />
                        <Tooltip 
                          cursor={{ fill: '#1F1F22' }}
                          contentStyle={{ backgroundColor: '#0F0F11', border: '1px solid #1F1F22', borderRadius: '4px' }}
                        />
                        <Bar dataKey="value" fill="#F27D26" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <AnalyticsCard title="Avg Response Time" value="124ms" trend="-12%" trendUp={false} />
                  <AnalyticsCard title="Error Rate" value="0.04%" trend="+0.01%" trendUp={true} />
                  <AnalyticsCard title="Active Connections" value="1.2M" trend="+18%" trendUp={true} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Service Detail Modal */}
        <AnimatePresence>
          {selectedService && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="bg-[#0F0F11] border border-[#1F1F22] rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl"
              >
                <div className="p-6 border-b border-[#1F1F22] flex items-center justify-between bg-[#1F1F22]/30">
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${
                      selectedService.status === 'healthy' ? 'bg-emerald-500' :
                      selectedService.status === 'degraded' ? 'bg-amber-500' :
                      selectedService.status === 'down' ? 'bg-rose-500' : 'bg-blue-500'
                    }`} />
                    <div>
                      <h2 className="text-xl font-bold tracking-tighter uppercase">{selectedService.name}</h2>
                      <p className="text-xs text-[#52525B] font-bold tracking-widest uppercase">{selectedService.id} • {selectedService.version}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setSelectedService(null)}
                    className="p-2 hover:bg-[#1F1F22] rounded-full transition-colors"
                  >
                    <X size={20} />
                  </button>
                </div>

                <div className="p-8 grid grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <DetailItem label="Domain" value={selectedService.domain} icon={<Layers size={16} />} />
                    <DetailItem label="Runtime Language" value={selectedService.language} icon={<Globe size={16} />} />
                    <DetailItem label="Uptime" value={selectedService.uptime} icon={<Clock size={16} />} />
                    <DetailItem label="Last Deployment" value={new Date(selectedService.lastDeployment).toLocaleString()} icon={<Activity size={16} />} />
                  </div>
                  <div className="space-y-6">
                    <div className="p-4 bg-[#0A0A0B] border border-[#1F1F22] rounded-lg">
                      <h4 className="text-[10px] uppercase tracking-widest text-[#52525B] font-bold mb-4">Real-time Metrics</h4>
                      <div className="space-y-4">
                        <ResourceMetric label="CPU Usage" value={selectedService.cpu} color="bg-[#F27D26]" />
                        <ResourceMetric label="Memory (MB)" value={Math.round((selectedService.memory / 1024) * 100)} color="bg-blue-500" />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="flex-1 bg-[#F27D26] text-black font-bold py-2 rounded text-xs uppercase tracking-widest hover:bg-orange-400 transition-colors">Restart Node</button>
                      <button className="flex-1 border border-[#1F1F22] font-bold py-2 rounded text-xs uppercase tracking-widest hover:bg-[#1F1F22] transition-colors">View Logs</button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Footer / Status Bar */}
        <footer className="h-8 border-t border-[#1F1F22] bg-[#0F0F11] px-4 flex items-center justify-between text-[10px] text-[#52525B] uppercase tracking-widest">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                wsStatus === 'connected' ? 'bg-emerald-500' : 
                wsStatus === 'connecting' ? 'bg-amber-500' : 'bg-rose-500'
              }`} />
              <span>
                {wsStatus === 'connected' ? 'Live Stream Active' : 
                 wsStatus === 'connecting' ? 'Connecting Stream...' : 
                 wsStatus === 'error' ? 'Stream Error' : 'Stream Offline'}
              </span>
            </div>
            <div className="h-3 w-px bg-[#1F1F22]" />
            <span>Last Sync: {new Date().toLocaleTimeString()}</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Region: Global-Cluster-01</span>
            <span>v2.4.0-production</span>
          </div>
        </footer>
      </main>
    </div>
  );
}

function StatCard({ label, value, icon, color }: { label: string, value: number | string, icon: React.ReactNode, color: string }) {
  return (
    <div className="bg-[#0F0F11] border border-[#1F1F22] p-4 rounded-lg flex items-center justify-between">
      <div>
        <p className="text-[10px] uppercase tracking-widest text-[#52525B] font-bold mb-1">{label}</p>
        <p className={`text-2xl font-bold tracking-tighter ${color}`}>{value}</p>
      </div>
      <div className="p-3 bg-[#1F1F22] rounded-lg text-[#A1A1AA]">
        {icon}
      </div>
    </div>
  );
}

function ResourceMetric({ label, value, color }: { label: string, value: number, color: string }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold">
        <span className="text-[#A1A1AA]">{label}</span>
        <span>{value}%</span>
      </div>
      <div className="h-1.5 bg-[#1F1F22] rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className={`h-full ${color}`}
        />
      </div>
    </div>
  );
}

function AnalyticsCard({ title, value, trend, trendUp }: { title: string, value: string, trend: string, trendUp: boolean }) {
  return (
    <div className="bg-[#0F0F11] border border-[#1F1F22] p-6 rounded-lg">
      <p className="text-[10px] uppercase tracking-widest text-[#52525B] font-bold mb-2">{title}</p>
      <div className="flex items-baseline gap-3">
        <h4 className="text-3xl font-bold tracking-tighter">{value}</h4>
        <span className={`text-[10px] font-bold ${trendUp ? 'text-rose-500' : 'text-emerald-500'}`}>
          {trend}
        </span>
      </div>
    </div>
  );
}

function DetailItem({ label, value, icon }: { label: string, value: string, icon: React.ReactNode }) {
  return (
    <div className="flex items-start gap-4">
      <div className="p-2 bg-[#1F1F22] rounded text-[#52525B]">
        {icon}
      </div>
      <div>
        <p className="text-[10px] uppercase tracking-widest text-[#52525B] font-bold mb-1">{label}</p>
        <p className="text-sm font-bold text-[#A1A1AA]">{value}</p>
      </div>
    </div>
  );
}

function StatusFilterButton({ status, active, onClick, icon }: { status: ServiceStatus, active: boolean, onClick: () => void, icon: React.ReactNode }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full text-left px-3 py-2 rounded text-sm transition-colors flex items-center gap-3 ${active ? 'bg-[#1F1F22] text-[#F27D26]' : 'hover:bg-[#1F1F22]/50 text-[#A1A1AA]'}`}
    >
      {icon}
      <span className="capitalize">{status}</span>
    </button>
  );
}
