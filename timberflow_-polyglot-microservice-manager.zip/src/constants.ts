import { Microservice, ServiceStatus } from './types';

export const DOMAINS = [
  'Forestry & Supply',
  'Manufacturing',
  'Product & Design',
  'Inventory & Warehouse',
  'Sales & Marketing',
  'Logistics',
  'Customer Support',
  'Finance & Admin',
  'Cross-cutting'
];

export const LANGUAGES = [
  { name: 'Go', color: '#00ADD8' },
  { name: 'Rust', color: '#DEA584' },
  { name: 'Python', color: '#3776AB' },
  { name: 'Java', color: '#007396' },
  { name: 'TypeScript', color: '#3178C6' },
  { name: 'Elixir', color: '#4E2A8E' },
  { name: 'C++', color: '#00599C' },
  { name: 'Ruby', color: '#CC342D' },
  { name: 'Kotlin', color: '#7F52FF' },
  { name: 'Scala', color: '#DC322F' },
  { name: 'PHP', color: '#777BB4' },
  { name: 'C#', color: '#239120' },
  { name: 'COBOL', color: '#005C92' },
  { name: 'Zig', color: '#F7A41D' },
  { name: 'Erlang', color: '#A90533' },
  { name: 'Haskell', color: '#5D4F85' },
  { name: 'Swift', color: '#F05138' },
  { name: 'Lua', color: '#000080' }
];

const STATUSES: ServiceStatus[] = ['healthy', 'healthy', 'healthy', 'healthy', 'healthy', 'degraded', 'down', 'starting'];

export const generateMockServices = (count: number): Microservice[] => {
  const services: Microservice[] = [];
  for (let i = 1; i <= count; i++) {
    const domain = DOMAINS[Math.floor(Math.random() * DOMAINS.length)];
    const langObj = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
    const status = STATUSES[Math.floor(Math.random() * STATUSES.length)];
    
    services.push({
      id: `svc-${i.toString().padStart(4, '0')}`,
      name: `${domain.split(' ')[0]}-${langObj.name.toLowerCase()}-${i}`,
      domain,
      language: langObj.name,
      status,
      version: `v1.${Math.floor(Math.random() * 5)}.${Math.floor(Math.random() * 20)}`,
      cpu: Math.floor(Math.random() * 80) + 5,
      memory: Math.floor(Math.random() * 1024) + 128,
      uptime: `${Math.floor(Math.random() * 30)}d ${Math.floor(Math.random() * 24)}h`,
      lastDeployment: new Date(Date.now() - Math.random() * 10000000000).toISOString()
    });
  }
  return services;
};
