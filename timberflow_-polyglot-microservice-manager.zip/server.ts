import express from "express";
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ server });
  const PORT = 3000;

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // WebSocket logic
  wss.on("connection", (ws) => {
    console.log("Client connected to WebSocket");
    
    // Send initial welcome message
    ws.send(JSON.stringify({ type: "CONNECTED", message: "Real-time stream established" }));

    ws.on("close", () => {
      console.log("Client disconnected");
    });
  });

  // Broadcast random updates every 2 seconds
  setInterval(() => {
    const updateCount = Math.floor(Math.random() * 5) + 1;
    const updates = Array.from({ length: updateCount }).map(() => {
      const id = `svc-${Math.floor(Math.random() * 1000 + 1).toString().padStart(4, '0')}`;
      const statusRoll = Math.random();
      let status = "healthy";
      if (statusRoll > 0.95) status = "down";
      else if (statusRoll > 0.85) status = "degraded";
      else if (statusRoll > 0.80) status = "starting";

      return {
        id,
        status,
        cpu: Math.floor(Math.random() * 80) + 5,
        memory: Math.floor(Math.random() * 1024) + 128,
        lastUpdate: new Date().toISOString()
      };
    });

    const payload = JSON.stringify({ type: "SERVICE_UPDATES", data: updates });
    
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    });
  }, 2000);

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
